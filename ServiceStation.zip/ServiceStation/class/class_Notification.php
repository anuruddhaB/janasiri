<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require '../assets/phpMailer/autoload.php';

require '../assets/phpMailer/Exception.php';
require '../assets/phpMailer/PHPMailer.php';
require '../assets/phpMailer/SMTP.php';
if (isset($_POST['path'])) {
    $methodName = $_POST['path'];
    $classObject = new Notification();
    $classObject->$methodName();
}
if (isset($_GET['path'])) {
    $methodName = $_GET['path'];
    $classObject = new Notification();
    $classObject->$methodName();
}

class Notification {

    function __construct() {
        $this->connection = new mysqli("localhost", "root", "", "jmt_db");
    }

    function userNotification() {
        $messageBox = [];
        $rid = filter_input(INPUT_POST, 'rid');
        $email = filter_input(INPUT_POST, 'email');

        $query = "select c.fname,c.lname,u.id,s.serviceSection,t.timeSlot,u.resdate,u.message,st.serviceName from userreservation u ,servicesection s ,servicetimeslot t ,servicetype st , customerlogin c where u.sectionid = s.id and u.timeslotid = t.id and u.userid = c.id and u.id ='$rid'";
        $resultset = $this->connection->query($query);
        if (mysqli_num_rows($resultset) !== 0) {
            if ($row = $resultset->fetch_assoc()) {
                $rid = $row['id'];
                $name = $row['fname'] . " " . $row['lname'];
                $section = $row['serviceSection'];
                $time = $row['timeSlot'];
                $resdate = $row['resdate'];
                $msg = $row['message'];
                $service = $row['serviceName'];
            }
            try {
                $mail = new PHPMailer();
                $mail->isSMTP();
                //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 587;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->SMTPAuth = true;
                $mail->Username = 'anonymousbusinesssolution@gmail.com';
                $mail->Password = 'Neeta@12430';
                $mail->setFrom('anonymousbusinesssolution@gmail.com', 'Janasiri Motor & Service Station');
                $mail->addReplyTo('anonymousbusinesssolution@gmail.com', 'Janasiri Motor & Service Station');
                $mail->addAddress($email, 'Janasiri Motor & Service Station');
                $mail->Subject = 'JMT - Customer Reservation Reminder';
                $mail->Body = "<html><body><h2>Customer Reservation</h2><ul><li>Res ID - $rid</li><li>Name - $name</li><li>Date - $resdate</li><li>Time - $time</li><li>Service - $service</li><li>Section - $section</li><li>Message - $msg</li></ul></body></html>";
                if (!$mail->send()) {
                    $messageBox = array("status" => false, "message" => "email not sent", "title" => "Customer Reminder");
                    echo json_encode($messageBox);
                } else {
                    $messageBox = array("status" => true, "message" => "email sent successfully", "title" => "Customer Reminder");
                    echo json_encode($messageBox);
                }
            } catch (Exception $exc) {
                $messageBox = array("status" => "exec", "message" => "something unexpected happen,please try again ->\n '$exc->getTraceAsString()'", "title" => "Something Unexpected");
                echo json_encode($messageBox);
            }
        } else {
            $messageBox = array("status" => "nan", "message" => "email sent successfully", "title" => "Customer Reminder");
            echo json_encode($messageBox);
        }
    }

}

?>  