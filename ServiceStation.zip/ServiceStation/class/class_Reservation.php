<?php

if (isset($_POST['path'])) {
    $methodName = $_POST['path'];
    $classObject = new Reservation();
    $classObject->$methodName();
}
if (isset($_GET['path'])) {
    $methodName = $_GET['path'];
    $classObject = new Reservation();
    $classObject->$methodName();
}

class Reservation {

    function __construct() {
        $this->connection = new mysqli("localhost", "root", "", "jmt_db");
    }

    function userReservation() {
        $messageBox = [];
        $username = filter_input(INPUT_POST, 'username');
        $year = filter_input(INPUT_POST, 'year');
        $vehicleModel = filter_input(INPUT_POST, 'vehicleModel');
        $timeSlot = filter_input(INPUT_POST, 'timeSlot');
        $serviceType = filter_input(INPUT_POST, 'serviceType');
        $message = filter_input(INPUT_POST, 'message');
        $date = filter_input(INPUT_POST, 'date');
        $section = 0;
        $queryuser = "select id from customerlogin where username='$username'";
        $resultuser = $this->connection->query($queryuser);
        if ($row = $resultuser->fetch_assoc()) {
            $userid = $row['id'];
        }
        $querytime = "select id from servicetimeslot where timeSlot='9.00AM'";
        $resulttime = $this->connection->query($querytime);
        if ($row = $resulttime->fetch_assoc()) {
            $timeid = $row['id'];
        }
        $queryservice = "select id from servicetype where serviceName='$serviceType'";
        $resultservice = $this->connection->query($queryservice);
        if ($row = $resultservice->fetch_assoc()) {
            $serviceid = $row['id'];
        }

        if ($userid == null || $userid == "") {
            $messageBox = array("status" => "basic", "message" => "user is not valid,please login with valid user", "title" => "Basic Data Fetching Failed");
            echo json_encode($messageBox);
            return true;
        } else if ($timeid == null || $timeid == "") {
            $messageBox = array("status" => "basic", "message" => "time slot is not valid,please login with valid time slot", "title" => "Basic Data Fetching Failed");
            echo json_encode($messageBox);
            return true;
        } else if ($serviceid == null || $serviceid == "") {
            $messageBox = array("status" => "basic", "message" => "service is not valid,please login with valid service", "title" => "Basic Data Fetching Failed");
            echo json_encode($messageBox);
            return true;
        } else {
            $resid = $this->generateValidReservationID();
            $datetime = $this->generateDateTime();
            $resdate = $datetime['date'];
            $restime = $datetime['time'];
            try {
                $queryreservation = "insert into userreservation "
                        . "values('$resid','$userid','$serviceid','$timeid','$message','$resdate','$restime','2','$vehicleModel','$year','Nothing','Nothing','$date','$section')";
                $this->connection->query($queryreservation);
                $messageBox = array("status" => true, "message" => "Successfully Submitted", "title" => "Reservation Complete");
                echo json_encode($messageBox);
            } catch (Exception $exc) {
                $messageBox = array("status" => false, "message" => "Data not submitted", "title" => "Reservation Incomplete");
                echo json_encode($messageBox);
                //echo $exc->getTraceAsString();
            }
        }
    }

    function generateValidReservationID() {
        $random = rand();
        $resid = "RES" . $random;
        $query = "select id from userreservation where id='$resid'";
        $result = $this->connection->query($query);
        if (mysqli_num_rows($result) == 0) {
            return $resid;
        } else {
            $this->generateValidReservationID();
        }
    }

    function generateDateTime() {
        date_default_timezone_set("Asia/Colombo");
        $date = date("Y-m-d");
        $time = date("h:i:sa");
        $datetime = array("date" => $date, "time" => $time);
        return $datetime;
    }

    function pendingReservationList() {
        $Query = "select u.id,c.fname ,c.lname,u.vehicleModel,t.timeSlot,u.message,u.resdate,s.serviceName from userreservation u,customerlogin c,servicetype s ,servicetimeslot t where u.servicetypeid = s.id and u.userid = c.id and u.timeslotid = t.id and u.status ='2' ";
        $resultSet = $this->connection->query($Query);
        $dataSet[] = array();
        while ($row = $resultSet->fetch_assoc()) {
            $id = $row['id'];
            $name = $row['fname'] . " " . $row['lname'];
            $vModel = $row['vehicleModel'];
            $time = $row['timeSlot'];
            $message = $row['message'];
            $service = $row['serviceName'];
            $date = $row['resdate'];
            $vModel = $row['vehicleModel'];
            echo "<tr>"
            . "<td>$id</td>"
            . "<td>$name</td>"
            . "<td>$vModel</td>"
            . "<td>$date</td>"
            . "<td>$service</td>"
            . "<td>"
            . "<input type='button' value='Approve' id='btn-app' class='btn btn-primary btn-sm' data-toggle='modal' data-target='#updateModal'>&nbsp;"
            . "<input type='button' value='Delete' id='btn-del' class='btn btn-danger btn-sm'>"
            . "</td>"
            . "</tr>";
        }
    }

    function updateReservation() {
        $sSection = filter_input(INPUT_POST, 'sSection');
        $rNote = filter_input(INPUT_POST, 'rNote');
        $oNote = filter_input(INPUT_POST, 'oNote');
        $rID = filter_input(INPUT_POST, 'rID');

        try {
            $Query = "update userreservation set replaceNote = '$rNote',note = '$oNote',sectionid = '1',status = '1' where id = '$rID'";
            $resultSet = $this->connection->query($Query);
            $messageBox = array("status" => true, "message" => "Successfully Submitted", "title" => "Reservation Complete");
            echo json_encode($messageBox);
        } catch (Exception $exc) {
            $messageBox = array("status" => false, "message" => "Data not submitted", "title" => "Reservation Incomplete");
            echo json_encode($messageBox);
        }
    }

    function generateReservation() {
        $rID = filter_input(INPUT_POST, 'rID');
        $dataset = [];
        try {
            $query = "select u.id,u.note,u.replaceNote,c.fname ,c.lname,c.email,c.contact,u.vehicleModel,u.Vehicleyear,t.timeSlot,u.message,u.resdate,s.serviceName from userreservation u,customerlogin c,servicetype s ,servicetimeslot t where u.servicetypeid = s.id and u.userid = c.id and u.timeslotid = t.id and u.status ='2' and u.id = '$rID'";
            $resultSet = $this->connection->query($query);
            if (mysqli_num_rows($resultSet) !== 0) {
                if ($row = $resultSet->fetch_assoc()) {
                    $id = $row['id'];
                    $resdate = $row['resdate'];
                    $name = $row['fname'] . " " . $row['lname'];
                    $contact = $row['contact'];
                    $vmodel = $row['vehicleModel'];
                    $year = $row['Vehicleyear'];
                    $service = $row['serviceName'];
                    $email = $row['email'];
                    $message = $row['message'];
                }
                $dataset = array('id' => $id, 'rdate' => $resdate, 'name' => $name, 'contact' => $contact, 'vmodel' => $vmodel, 'year' => $year, 'message' => $message, 'service' => $service, 'email' => $email);
                echo json_encode($dataset);
            } else {
                echo json_encode("No data");
            }
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }

}

?>
